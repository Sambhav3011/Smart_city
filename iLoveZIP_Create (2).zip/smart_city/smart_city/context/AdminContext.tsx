// AdminContext.tsx
import React, { createContext, useState } from 'react';

export const AdminContext = createContext<{ adminMode: boolean; setAdminMode?: (b: boolean) => void }>({ adminMode: false });

export const AdminProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [adminMode, setAdminMode] = useState(false);
  return <AdminContext.Provider value={{ adminMode, setAdminMode }}>{children}</AdminContext.Provider>;
};
