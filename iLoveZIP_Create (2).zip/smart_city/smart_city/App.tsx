import React, { useState, useEffect } from 'react';
import Sidebar from '@/components/Sidebar';
import CivicIssuesPage from '@/features/CivicIssuesPage';
import EnvironmentDashboard from '@/features/EnvironmentDashboard';
import AlertsPage from '@/features/AlertsPage';
import ResourcesPage from '@/features/ResourcesPage';
import ServicesPage from '@/features/ServicesPage';
import type { Page } from '@/types';
import { AdminContext } from "@/context/AdminContext";   // ⭐ ADD THIS

const App: React.FC = () => {
  const [activePage, setActivePage] = useState<Page>('Dashboard');
  const [adminMode, setAdminMode] = useState(false);

  const enableAdmin = () => {
    const pass = prompt("Enter admin password:");
    if (pass === "admin123") {
      setAdminMode(true);
      alert("Admin mode activated");
    } else {
      alert("Wrong password");
    }
  };

  useEffect(() => {
    if ((window as any).tsParticles) {
      (window as any).tsParticles.load("tsparticles", {
        fpsLimit: 60,
        background: { 
          color: "#3A0A1E"   // 🍷 Deep Wine Background
        },
        particles: {
          number: { 
            value: 50, 
            density: { enable: true, value_area: 800 } 
          },
          color: { 
            value: "#0eb453ff"  // black dots
          },
          shape: { type: "circle" },
          opacity: { 
            value: 0.5, 
            random: true 
          },
          size: { 
            value: 3, 
            random: true 
          },
          line_linked: {
            enable: true,
            distance: 150,
            color: "#76199bff", // black connecting lines
            opacity: 0.3,
            width: 1
          },
          move: { 
            enable: true, 
            speed: 2, 
            out_mode: "out" 
          }
        },
        interactivity: {
          detect_on: "canvas",
          events: {
            onhover: { enable: true, mode: "repulse" },
            onclick: { enable: true, mode: "push" },
            resize: true
          }
        },
        detectRetina: true
      });

    }
  }, []);


  const renderContent = () => {
    switch (activePage) {
      case "Civic Issues":
        return <CivicIssuesPage />;
      case "Environment":
        return <EnvironmentDashboard />;
      case "Alerts":
        return <AlertsPage />;
      case "Resources":
        return <ResourcesPage />;     // ⭐ NO NEED TO PASS adminMode BY PROP
      case "Services & Events":
        return <ServicesPage />;
      default:
        return <EnvironmentDashboard />;
    }
  };

  return (
    // ⭐ WRAP THE ENTIRE APP WITH CONTEXT
    <AdminContext.Provider value={{ adminMode, setAdminMode }}>
      <div className="relative h-screen w-full">
        <div id="tsparticles" className="absolute top-0 left-0 w-full h-full z-0" />
        <div className="relative z-10 flex h-screen bg-transparent text-gray-800 dark:text-gray-200">
          <Sidebar activePage={activePage} setActivePage={setActivePage} />
          <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
            {/* ADMIN BUTTON */}
            <button 
              onClick={enableAdmin} 
              className="mb-4 px-4 py-2 bg-yellow-500 text-black rounded"
            >
              Admin Mode
            </button>

            {renderContent()}
          </main>
        </div>
      </div>
    </AdminContext.Provider>
  );
};

export default App;
