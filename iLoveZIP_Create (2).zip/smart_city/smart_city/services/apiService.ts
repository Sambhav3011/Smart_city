// apiService.ts
const API_BASE = 'http://localhost:3001/api';

const handleResponse = async (response: Response) => {
  const text = await response.text();
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch (e) {
    throw new Error(`Invalid JSON response: ${text}`);
  }
  if (!response.ok) {
    const err = (json as any).error || response.statusText;
    throw new Error(err);
  }
  return (json as any).data;
};

const getData = async <T>(endpoint: string): Promise<T> => {
  const res = await fetch(`${API_BASE}${endpoint}`);
  return handleResponse(res) as Promise<T>;
};

const postData = async <B, R>(endpoint: string, body: B): Promise<R> => {
  const res = await fetch(`${API_BASE}${endpoint}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  return handleResponse(res) as Promise<R>;
};

const putData = async <B, R>(endpoint: string, body: B): Promise<R> => {
  const res = await fetch(`${API_BASE}${endpoint}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  return handleResponse(res) as Promise<R>;
};

const deleteData = async <R>(endpoint: string): Promise<R> => {
  const res = await fetch(`${API_BASE}${endpoint}`, { method: 'DELETE' });
  return handleResponse(res) as Promise<R>;
};

/* ----------------- Civic Issues ----------------- */
export const fetchIssues = async () => getData('/issues');
export const createIssue = async (issueData: any) => postData('/issues', issueData);
export const updateIssue = async (id: string, data: any) => putData(`/issues/${id}`, data);
export const deleteIssue = async (id: string) => deleteData(`/issues/${id}`);

// comments + status update
export const fetchIssueComments = async (issueId: string) => {
  const res = await fetch(`${API_BASE}/issues/${issueId}/comments`);
  if (!res.ok) throw new Error('Failed to load comments');
  const json = await res.json();
  return json.data;
};
export const postIssueComment = async (issueId: string, payload: { author: string; comment: string }) => {
  const res = await fetch(`${API_BASE}/issues/${issueId}/comments`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const t = await res.text();
    throw new Error(t || 'Failed to post comment');
  }
  const json = await res.json();
  return json.data;
};
export const updateIssueStatus = async (issueId: string, status: string) => {
  const res = await fetch(`${API_BASE}/issues/${issueId}/status`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ status }),
  });
  if (!res.ok) {
    const t = await res.text();
    throw new Error(t || 'Failed to update status');
  }
  const json = await res.json();
  return json;
};

/* ----------------- Alerts ----------------- */
export const fetchAlerts = async () => getData('/alerts');
export const createAlert = async (data: any) => postData('/alerts', data);
export const updateAlert = async (id: string, data: any) => putData(`/alerts/${id}`, data);
export const deleteAlert = async (id: string) => deleteData(`/alerts/${id}`);

/* ----------------- Resources ----------------- */
export const fetchResources = async () => getData('/resources');
export const createResource = async (data: any) => postData('/resources', data);
export const updateResource = async (id: string, data: any) => putData(`/resources/${id}`, data);
export const deleteResource = async (id: string) => deleteData(`/resources/${id}`);

/* ----------------- Services + Events ----------------- */
export const fetchServicesAndEvents = async () => getData('/services-events');
export const createService = async (data: any) => postData('/services', data);
export const updateService = async (id: string, data: any) => putData(`/services/${id}`, data);
export const deleteService = async (id: string) => deleteData(`/services/${id}`);

export const createEvent = async (data: any) => postData('/events', data);
export const updateEvent = async (id: string, data: any) => putData(`/events/${id}`, data);
export const deleteEvent = async (id: string) => deleteData(`/events/${id}`);

/* ----------------- Environmental ----------------- */
export const fetchEnvironmentalData = async () => {
  const res = await fetch(`${API_BASE}/environmental-data`);
  if (!res.ok) throw new Error('Failed to load environmental data');
  const json = await res.json();
  // always return array
  return Array.isArray(json.data) ? json.data : [];
};
export const fetchWeatherForecast = async () => {
  const res = await fetch(`${API_BASE}/weather-forecast`);
  if (!res.ok) throw new Error("Failed to load weather forecast");
  const json = await res.json();
  return json.data;
};
