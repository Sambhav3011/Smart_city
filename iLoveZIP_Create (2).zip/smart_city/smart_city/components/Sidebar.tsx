import React, { useState } from 'react';
import type { Page } from '@/types';
import { CityIcon, DashboardIcon, IssuesIcon, EnvironmentIcon, AlertsIcon, ResourcesIcon, ServicesIcon, MenuIcon, CloseIcon } from '@/components/icons';

interface SidebarProps {
  activePage: Page;
  setActivePage: (page: Page) => void;
}

const NavItem: React.FC<{
  icon: React.ReactNode;
  label: Page;
  isActive: boolean;
  onClick: () => void;
  isExpanded: boolean;
}> = ({ icon, label, isActive, onClick, isExpanded }) => (
  <li
    onClick={onClick}
    className={`
      flex items-center p-3 my-1 rounded-lg cursor-pointer transition-colors duration-200 z-10
      ${isActive
        ? 'bg-blue-600 text-white'
        : 'text-gray-400 hover:bg-gray-700 hover:text-white'
      }
    `}
  >
    {icon}
    <span className={`ml-4 transition-opacity duration-300 ${isExpanded ? 'opacity-100' : 'opacity-0'}`}>
      {label}
    </span>
  </li>
);

const Sidebar: React.FC<SidebarProps> = ({ activePage, setActivePage }) => {
  const [isExpanded, setIsExpanded] = useState(true);

  const navItems: { label: Page; icon: React.ReactNode }[] = [
    { label: 'Dashboard', icon: <DashboardIcon /> },
    { label: 'Civic Issues', icon: <IssuesIcon /> },
    { label: 'Environment', icon: <EnvironmentIcon /> },
    { label: 'Alerts', icon: <AlertsIcon /> },
    { label: 'Resources', icon: <ResourcesIcon /> },
    { label: 'Services & Events', icon: <ServicesIcon /> },
  ];
  
  const currentPage = navItems.find(item => item.label === activePage) ? activePage : 'Dashboard';

  return (
    <div className={`relative bg-gray-800/80 backdrop-blur-sm text-white flex flex-col transition-all duration-300 ease-in-out ${isExpanded ? 'w-64' : 'w-20'}`}>
      <div className="flex items-center justify-between p-4 h-16 border-b border-gray-700/50">
        <div className={`flex items-center transition-opacity duration-300 ${isExpanded ? 'opacity-100' : 'opacity-0'}`}>
          <CityIcon />
          <span className="text-xl font-bold ml-2 flex items-center">
            <span className="text-white">Smart</span>
            <span className="ml-1 bg-orange-500 text-black px-2 py-0.5 rounded">
              City
            </span>
          </span>
        </div>

        <button onClick={() => setIsExpanded(!isExpanded)} className="p-2 rounded-lg hover:bg-gray-700 z-10">
          {isExpanded ? <CloseIcon /> : <MenuIcon />}
        </button>
      </div>

      <nav className="flex-1 p-2">
        <ul>
          {navItems.map((item) => (
            <NavItem
              key={item.label}
              icon={item.icon}
              label={item.label}
              isActive={currentPage === item.label}
              onClick={() => setActivePage(item.label)}
              isExpanded={isExpanded}
            />
          ))}
        </ul>
      </nav>
    </div>
  );
};

export default Sidebar;