import os
import subprocess
import sys
import time
from pathlib import Path
import shutil

def find_npm():
    possible_paths = [
        r"C:\Program Files\nodejs\npm.cmd",
        r"C:\Program Files\nodejs\npm.exe",
        r"C:\Program Files (x86)\nodejs\npm.cmd",
        r"C:\Program Files (x86)\nodejs\npm.exe",
        str(Path.home() / "AppData/Roaming/npm/npm.cmd"),
        str(Path.home() / "AppData/Roaming/npm/npm.exe"),
    ]

    npm = shutil.which("npm")
    if npm:
        return npm

    for p in possible_paths:
        if os.path.exists(p):
            return p

    print("❌ npm not found. Install Node.js from https://nodejs.org/")
    sys.exit(1)


NPM_CMD = find_npm()

BACKEND_DIR = "."        # your backend is in root folder
FRONTEND_DIR = "."       # your frontend is ALSO in root folder

def run_backend():
    print("🚀 Starting backend server...")
    return subprocess.Popen(
        ["node", "server.js"],
        cwd=BACKEND_DIR,
        shell=True
    )

def run_frontend():
    print("🌐 Starting frontend (Vite)...")
    return subprocess.Popen(
        [NPM_CMD, "run", "dev"],
        cwd=FRONTEND_DIR,
        shell=True
    )

def main():
    print("=====================================")
    print("  SMART CITY — Python Launch Script  ")
    print("=====================================")

    backend = run_backend()
    time.sleep(2)

    frontend = run_frontend()

    print("✔ Everything started successfully.\n")
    print("🔔 Keep this terminal open!\n")

    try:
        backend.wait()
        frontend.wait()
    except KeyboardInterrupt:
        backend.terminate()
        frontend.terminate()
        print("\nShutdown complete.")

if __name__ == "__main__":
    main()
