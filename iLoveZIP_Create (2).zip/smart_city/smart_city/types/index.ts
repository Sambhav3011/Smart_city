export type Page = 'Dashboard' | 'Civic Issues' | 'Environment' | 'Alerts' | 'Resources' | 'Services & Events';

export interface CivicIssue {
  id: string;
  category: 'Pothole' | 'Streetlight Out' | 'Waste Management' | 'Public Vandalism' | 'Other';
  title: string;
  description: string;
  location: string;
  status: 'Open' | 'In-Progress' | 'Resolved';
  timestamp: string;
  photo?: string; // Base64 encoded string
}

export interface EnvironmentalReading {
  timestamp: string;
  airQuality: number; // PM2.5
  waterQuality: number; // pH
  noiseLevel: number; // dB
}

export interface PublicAlert {
  id: string;
  title: string;
  description:string;
  category: 'Health' | 'Weather' | 'Traffic' | 'Emergency';
  priority: 'Low' | 'Medium' | 'High';
  timestamp: string;
}

export interface Resource {
  id: string;
  name: string;
  type: 'Volunteer' | 'Ambulance' | 'Food Supply' | 'Shelter';
  contact: string;
  capacity: string;
  status: 'Available' | 'Unavailable';
}

export interface Service {
  id: string;
  name: string;
  type: 'Hospital' | 'Police Station' | 'Fire Station' | 'Blood Bank';
  address: string;
  contact: string;
}

export interface CommunityEvent {
  id: string;
  title: string;
  description: string;
  date: string;
  location: string;
  organizer: string;
}
