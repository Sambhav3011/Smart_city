// ResourcesPage.tsx
import React, { useState, useEffect, useCallback, useContext } from "react";
import { fetchResources, createResource, updateResource, deleteResource } from "@/services/apiService";
import { AdminContext } from "@/context/AdminContext";
import type { Resource } from "@/types";

const ResourceCard: React.FC<{
  resource: Resource;
  adminMode: boolean;
  editingId: string | null;
  setEditingId: (id: string | null) => void;
  editData: any;
  setEditData: (d: any) => void;
  onDelete: (id: string) => void;
  onSave: (id: string) => void;
}> = ({ resource, adminMode, editingId, setEditingId, editData, setEditData, onDelete, onSave }) => {
  const isEditing = editingId === resource.id;
  return (
    <div className="bg-white/10 backdrop-blur-sm dark:bg-gray-800/50 rounded-lg shadow p-4">
      {!isEditing && (
        <>
          <div className="flex justify-between items-center">
            <h3 className="font-bold text-lg text-white">{resource.name}</h3>
            <span className={`px-2 py-1 text-xs rounded-full ${resource.status === "Available" ? "bg-green-200 text-green-800" : "bg-gray-200 text-gray-800"}`}>{resource.status}</span>
          </div>

          <p className="text-sm text-blue-400">{resource.type}</p>
          <p className="text-sm text-gray-300 mt-2">Capacity: {resource.capacity}</p>
          <p className="text-sm text-gray-300">Contact: {resource.contact}</p>

          {adminMode && (
            <div className="mt-4 flex gap-2">
              <button onClick={() => { setEditingId(resource.id); setEditData({ ...resource }); }} className="bg-yellow-500 text-black px-3 py-1 rounded text-sm">Edit</button>
              <button onClick={() => onDelete(resource.id)} className="bg-red-600 text-white px-3 py-1 rounded text-sm">Delete</button>
            </div>
          )}
        </>
      )}

      {isEditing && (
        <div className="space-y-3">
          <input className="w-full p-2 rounded bg-gray-800 text-white" value={editData.name} onChange={(e) => setEditData({ ...editData, name: e.target.value })} />
          <select className="w-full p-2 rounded bg-gray-800 text-white" value={editData.type} onChange={(e) => setEditData({ ...editData, type: e.target.value })}>
            <option>Volunteer</option>
            <option>Ambulance</option>
            <option>Food Supply</option>
            <option>Shelter</option>
          </select>
          <input className="w-full p-2 rounded bg-gray-800 text-white" value={editData.contact} onChange={(e) => setEditData({ ...editData, contact: e.target.value })} />
          <textarea className="w-full p-2 rounded bg-gray-800 text-white" value={editData.capacity} onChange={(e) => setEditData({ ...editData, capacity: e.target.value })} />
          <div className="flex gap-2 mt-3">
            <button onClick={() => onSave(resource.id)} className="bg-green-600 text-white px-3 py-1 rounded text-sm">Save</button>
            <button onClick={() => setEditingId(null)} className="bg-gray-500 text-white px-3 py-1 rounded text-sm">Cancel</button>
          </div>
        </div>
      )}
    </div>
  );
};

const ResourcesPage: React.FC = () => {
  const { adminMode } = useContext(AdminContext);
  const [resources, setResources] = useState<Resource[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editData, setEditData] = useState<any>({});

  const [showAddForm, setShowAddForm] = useState(false);
  const [newResource, setNewResource] = useState({ name: "", type: "Volunteer", contact: "", capacity: "" });

  const loadResources = useCallback(async () => {
    setIsLoading(true);
    try {
      const data = await fetchResources();
      setResources(data || []);
    } catch (err) {
      console.error("Failed to load resources", err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadResources();
  }, [loadResources]);

  const handleDelete = async (id: string) => {
    if (!confirm("Delete this resource?")) return;
    try {
      await deleteResource(id);
      loadResources();
    } catch (err) {
      console.error("Failed to delete resource", err);
      alert("Failed to delete resource");
    }
  };

  const handleSave = async (id: string) => {
    try {
      await updateResource(id, editData);
      setEditingId(null);
      loadResources();
    } catch (err) {
      console.error("Failed to update resource", err);
      alert("Failed to update resource");
    }
  };

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createResource(newResource);
      setNewResource({ name: "", type: "Volunteer", contact: "", capacity: "" });
      setShowAddForm(false);
      loadResources();
    } catch (err) {
      console.error("Failed to add resource", err);
      alert("Failed to add resource");
    }
  };

  return (
    <div className="container mx-auto">
      <h1 className="text-3xl font-bold text-white mb-6">Resource & Volunteer Management</h1>

      {adminMode && (
        <>
          <button onClick={() => setShowAddForm(!showAddForm)} className="mb-4 px-4 py-2 bg-blue-600 text-white rounded">
            {showAddForm ? "Close Form" : "Add Resource"}
          </button>

          {showAddForm && (
            <form onSubmit={handleAdd} className="bg-gray-800 p-6 rounded mb-6 max-w-md">
              <h3 className="text-lg font-semibold text-white mb-3">Add New Resource</h3>
              <input placeholder="Name" className="w-full p-2 mb-3 bg-gray-700 rounded text-white" value={newResource.name} onChange={(e) => setNewResource({ ...newResource, name: e.target.value })} required />
              <select className="w-full p-2 mb-3 bg-gray-700 rounded text-white" value={newResource.type} onChange={(e) => setNewResource({ ...newResource, type: e.target.value })}>
                <option>Volunteer</option>
                <option>Ambulance</option>
                <option>Food Supply</option>
                <option>Shelter</option>
                <option>Other</option>
              </select>
              <input placeholder="Contact" className="w-full p-2 mb-3 bg-gray-700 rounded text-white" value={newResource.contact} onChange={(e) => setNewResource({ ...newResource, contact: e.target.value })} required />
              <textarea placeholder="Capacity / Details" className="w-full p-2 mb-3 bg-gray-700 rounded text-white" value={newResource.capacity} onChange={(e) => setNewResource({ ...newResource, capacity: e.target.value })} rows={3} required />
              <div className="flex gap-2">
                <button type="submit" className="bg-green-600 text-white px-4 py-2 rounded">Save</button>
                <button type="button" onClick={() => { setShowAddForm(false); setNewResource({ name: "", type: "Volunteer", contact: "", capacity: "" }); }} className="bg-gray-500 text-white px-4 py-2 rounded">Cancel</button>
              </div>
            </form>
          )}
        </>
      )}

      {isLoading ? (
        <div className="text-center text-white">Loading...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {resources.map((r) => (
            <ResourceCard
              key={r.id}
              resource={r}
              adminMode={adminMode}
              editingId={editingId}
              setEditingId={setEditingId}
              editData={editData}
              setEditData={setEditData}
              onDelete={handleDelete}
              onSave={handleSave}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default ResourcesPage;
