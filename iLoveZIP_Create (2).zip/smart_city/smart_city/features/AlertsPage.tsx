// AlertsPage.tsx
import React, { useEffect, useState, useCallback, useContext } from "react";
import { fetchAlerts, createAlert, updateAlert, deleteAlert } from "@/services/apiService";
import { AdminContext } from "@/context/AdminContext";

type AlertItem = {
  id: string;
  title: string;
  description: string;
  category?: string;
  priority?: string;
  timestamp?: string;
};

const AlertCard: React.FC<{ alert: AlertItem; adminMode: boolean; onEdit: (a: AlertItem) => void; onDelete: (id: string) => void }> = ({ alert, adminMode, onEdit, onDelete }) => (
  <div className="bg-white/10 backdrop-blur-sm p-4 rounded-lg shadow">
    <h3 className="text-lg font-bold text-white">{alert.title}</h3>
    <p className="text-gray-300 mt-2">{alert.description}</p>
    {alert.category && <p className="text-sm text-blue-400 mt-1">Category: {alert.category}</p>}
    <p className="text-gray-500 text-xs mt-2">{alert.timestamp ? new Date(alert.timestamp).toLocaleString() : ""}</p>

    {adminMode && (
      <div className="flex gap-3 mt-4">
        <button className="px-3 py-1 bg-yellow-600 rounded" onClick={() => onEdit(alert)}>Edit</button>
        <button className="px-3 py-1 bg-red-600 rounded" onClick={() => onDelete(alert.id)}>Delete</button>
      </div>
    )}
  </div>
);

const AlertsPage: React.FC = () => {
  const { adminMode } = useContext(AdminContext);
  const [alerts, setAlerts] = useState<AlertItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingAlert, setEditingAlert] = useState<AlertItem | null>(null);

  const [form, setForm] = useState({
    title: "",
    description: "",
    category: "",
    priority: "Low",
  });

  const loadAlerts = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchAlerts();
      setAlerts(data || []);
    } catch (err) {
      console.error("Failed to load alerts", err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadAlerts();
  }, [loadAlerts]);

  const submitAlert = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingAlert) {
        await updateAlert(editingAlert.id, form);
      } else {
        await createAlert(form);
      }
      setForm({ title: "", description: "", category: "", priority: "Low" });
      setEditingAlert(null);
      setShowForm(false);
      loadAlerts();
    } catch (err) {
      console.error("Failed to save alert", err);
      alert("Failed to save alert. Check console for details.");
    }
  };

  return (
    <div className="container mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-white">City Alerts</h1>

        {adminMode && (
          <button
            className="px-4 py-2 bg-blue-600 text-white rounded"
            onClick={() => {
              setEditingAlert(null);
              setForm({ title: "", description: "", category: "", priority: "Low" });
              setShowForm(true);
            }}
          >
            Add Alert
          </button>
        )}
      </div>

      {loading ? (
        <p className="text-white">Loading...</p>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {alerts.map((a) => (
            <AlertCard
              key={a.id}
              alert={a}
              adminMode={adminMode}
              onEdit={(al) => {
                setEditingAlert(al);
                setForm({ title: al.title || "", description: al.description || "", category: al.category || "", priority: al.priority || "Low" });
                setShowForm(true);
              }}
              onDelete={async (id) => {
                if (confirm("Delete this alert?")) {
                  await deleteAlert(id);
                  loadAlerts();
                }
              }}
            />
          ))}
        </div>
      )}

      {showForm && (
        <div className="fixed inset-0 bg-black/70 flex justify-center items-center z-50">
          <form className="bg-gray-800 p-6 rounded w-96 text-white" onSubmit={submitAlert}>
            <h3 className="text-lg mb-4">{editingAlert ? "Edit Alert" : "Add Alert"}</h3>

            <input placeholder="Title" className="p-2 mb-3 w-full bg-gray-700 rounded" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required />

            <textarea placeholder="Description" className="p-2 mb-3 w-full bg-gray-700 rounded" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} required />

            <input placeholder="Category (e.g. Weather, Road)" className="p-2 mb-3 w-full bg-gray-700 rounded" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} />

            <select className="p-2 mb-3 w-full bg-gray-700 rounded" value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })}>
              <option>Low</option>
              <option>Medium</option>
              <option>High</option>
            </select>

            <button className="bg-blue-600 py-2 rounded w-full">Save</button>
            <button type="button" className="bg-red-600 mt-3 py-2 rounded w-full" onClick={() => setShowForm(false)}>Cancel</button>
          </form>
        </div>
      )}
    </div>
  );
};

export default AlertsPage;
