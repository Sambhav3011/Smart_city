// CivicIssuesPage.tsx
import React, { useCallback, useEffect, useState, useContext } from 'react';
import { fetchIssues, createIssue, fetchIssueComments, postIssueComment, updateIssueStatus } from '@/services/apiService';
import { AdminContext } from '@/context/AdminContext';
import { PlusIcon, UploadIcon } from '@/components/icons';

const splitIntoSentences = (text: string) => text.match(/[^.!?]+[.!?]*/g) || [text];

const ShortDescription = ({ text, onReadMore }: { text: string; onReadMore: () => void }) => {
  const s = splitIntoSentences(text);
  if (s.length <= 3) return <p className="text-gray-300">{text}</p>;
  const preview = s.slice(0, 3).join(' ').trim();
  return (
    <p className="text-gray-300">
      {preview} <button className="text-blue-400 underline" onClick={onReadMore}>Read more</button>
    </p>
  );
};

const IssueCard = ({ issue, onOpen }: any) => (
  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 shadow-md hover:scale-102 transition-transform cursor-pointer" onClick={() => onOpen(issue)}>
    <div className="flex justify-between items-start">
      <h3 className="text-lg font-bold text-white">{issue.title}</h3>
      <span className={`text-xs px-2 py-1 rounded-full ${issue.status === 'Open' ? 'bg-red-500' : issue.status === 'In-Progress' ? 'bg-yellow-500' : 'bg-green-600'} text-white`}>
        {issue.status}
      </span>
    </div>
    <p className="text-sm text-blue-400 font-semibold mt-1">{issue.category}</p>
    <div className="mt-2"><ShortDescription text={issue.description} onReadMore={() => onOpen(issue)} /></div>
    {issue.photo && <img className="mt-3 rounded object-cover w-full max-h-40" src={issue.photo} alt="issue" />}
    <div className="mt-3 text-xs text-gray-400">
      <div>Location: {issue.location}</div>
      <div>Reported: {issue.timestamp ? new Date(issue.timestamp).toLocaleString() : ''}</div>
    </div>
  </div>
);

const CivicIssuesPage: React.FC = () => {
  const { adminMode } = useContext(AdminContext);
  const [issues, setIssues] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newIssue, setNewIssue] = useState<any>({ category: 'Pothole', status: 'Open' });
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);

  const [selected, setSelected] = useState<any | null>(null);
  const [comments, setComments] = useState<any[]>([]);
  const [commentText, setCommentText] = useState('');

  const loadIssues = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchIssues();
      setIssues(data || []);
    } catch (err) {
      console.error('Failed to load issues', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadIssues(); }, [loadIssues]);

  const openIssue = async (issue: any) => {
    setSelected(issue);
    try {
      const c = await fetchIssueComments(issue.id);
      setComments(c || []);
    } catch (err) {
      console.error('Failed to load comments', err);
      setComments([]);
    }
  };
  const closeIssue = () => { setSelected(null); setComments([]); setCommentText(''); };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      const r = reader.result as string;
      setPhotoPreview(r);
      setNewIssue(prev => ({ ...prev, photo: r }));
    };
    reader.readAsDataURL(file);
  };

  const submitNewIssue = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newIssue.description || !newIssue.location) return alert('Fill required fields');
    try {
      await createIssue(newIssue);
      setIsModalOpen(false);
      setNewIssue({ category: 'Pothole', status: 'Open' });
      setPhotoPreview(null);
      await loadIssues();
    } catch (err) {
      console.error(err);
      alert('Failed to submit issue');
    }
  };

  const submitComment = async () => {
    if (!selected) return;
    if (!commentText.trim()) return alert('Type a comment');
    try {
      const author = adminMode ? 'Admin' : 'Citizen';
      await postIssueComment(selected.id, { author, comment: commentText });
      const c = await fetchIssueComments(selected.id);
      setComments(c || []);
      setCommentText('');
    } catch (err) {
      console.error('Failed to post comment', err);
      alert('Failed to post comment');
    }
  };

  const changeStatus = async (newStatus: string) => {
    if (!selected) return;
    try {
      await updateIssueStatus(selected.id, newStatus);
      await loadIssues();
      setSelected(prev => prev ? { ...prev, status: newStatus } : prev);
    } catch (err) {
      console.error('Failed to update status', err);
      alert('Failed to update status');
    }
  };

  return (
    <div className="container mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-white">Civic Issue Reports</h1>
        <button onClick={() => setIsModalOpen(true)} className="flex items-center bg-blue-600 text-white px-4 py-2 rounded-lg">
          <PlusIcon /><span className="ml-2">Report New Issue</span>
        </button>
      </div>

      {loading ? <div className="text-white">Loading...</div> : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {issues.map(i => <IssueCard key={i.id} issue={i} onOpen={openIssue} />)}
        </div>
      )}

      {isModalOpen && (
        <div className="fixed inset-0 bg-black/70 flex justify-center items-center z-50">
          <div className="bg-gray-800 rounded-lg p-6 w-full max-w-lg text-white">
            <h2 className="text-2xl font-bold mb-4">Report a New Issue</h2>
            <form onSubmit={submitNewIssue}>
              <div className="mb-3">
                <label className="block mb-1">Category</label>
                <select className="w-full p-2 rounded bg-gray-700" value={newIssue.category} onChange={e => setNewIssue({ ...newIssue, category: e.target.value })}>
                  <option>Pothole</option><option>Streetlight Out</option><option>Waste Management</option><option>Public Vandalism</option><option>Other</option>
                </select>
              </div>
              <div className="mb-3">
                <label className="block mb-1">Description</label>
                <textarea required className="w-full p-2 rounded bg-gray-700" rows={4} value={newIssue.description || ''} onChange={e => setNewIssue({ ...newIssue, description: e.target.value })} />
              </div>
              <div className="mb-3">
                <label className="block mb-1">Location</label>
                <input required className="w-full p-2 rounded bg-gray-700" value={newIssue.location || ''} onChange={e => setNewIssue({ ...newIssue, location: e.target.value })} />
              </div>
              <div className="mb-4">
                <label className="block mb-2">Upload Photo (optional)</label>
                <label htmlFor="file-upload" className="cursor-pointer flex items-center gap-3 p-3 border-2 border-dashed rounded bg-gray-700 hover:bg-gray-600">
                  <UploadIcon /> <span>Choose image</span>
                </label>
                <input id="file-upload" type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
                {photoPreview && <img src={photoPreview} className="mt-3 max-h-40 w-full object-cover rounded" alt="preview" />}
              </div>
              <div className="flex gap-3">
                <button type="submit" className="px-4 py-2 bg-green-600 rounded">Submit</button>
                <button type="button" className="px-4 py-2 bg-red-600 rounded" onClick={() => setIsModalOpen(false)}>Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {selected && (
        <div className="fixed inset-0 bg-black/70 flex justify-center items-start z-50 overflow-auto py-10">
          <div className="bg-gray-900 rounded-lg p-6 w-full max-w-2xl text-white">
            <div className="flex justify-between items-start">
              <div>
                <h2 className="text-2xl font-bold">{selected.title}</h2>
                <p className="text-sm text-blue-400 mt-1">{selected.category}</p>
                <p className="text-xs text-gray-400 mt-1">Reported: {selected.timestamp ? new Date(selected.timestamp).toLocaleString() : ''}</p>
              </div>
              <div>
                <div className={`px-3 py-1 rounded text-white ${selected.status === 'Open' ? 'bg-red-500' : selected.status === 'In-Progress' ? 'bg-yellow-500' : 'bg-green-600'}`}>
                  {selected.status}
                </div>
              </div>
            </div>

            <div className="mt-4">
              <h3 className="text-lg font-semibold">Description</h3>
              <p className="text-gray-300 mt-2 whitespace-pre-wrap">{selected.description}</p>
            </div>

            <div className="mt-6">
              <h3 className="text-lg font-semibold">Comments</h3>
              <div className="space-y-3 mt-3">
                {comments.length === 0 && <p className="text-gray-400">No comments yet.</p>}
                {comments.map(c => (
                  <div key={c.id} className="bg-gray-800 p-3 rounded">
                    <div className="flex justify-between items-center">
                      <strong>{c.author}</strong>
                      <span className="text-xs text-gray-400">{new Date(c.timestamp).toLocaleString()}</span>
                    </div>
                    <p className="text-gray-300 mt-1">{c.comment}</p>
                  </div>
                ))}
              </div>

              <div className="mt-4">
                <textarea className="w-full p-2 bg-gray-700 rounded text-white" rows={3} placeholder="Add a comment..." value={commentText} onChange={e => setCommentText(e.target.value)} />
                <div className="flex gap-3 mt-2">
                  <button className="px-4 py-2 bg-blue-600 rounded" onClick={submitComment}>Post Comment</button>
                  <button className="px-4 py-2 bg-gray-600 rounded" onClick={() => setCommentText('')}>Clear</button>
                </div>
              </div>
            </div>

            {adminMode && (
              <div className="mt-6">
                <h3 className="text-lg font-semibold">Admin Controls</h3>
                <div className="mt-3 flex gap-3 items-center">
                  <label className="text-sm text-gray-300">Status:</label>
                  <select className="p-2 rounded bg-gray-700" value={selected.status} onChange={e => changeStatus(e.target.value)}>
                    <option>Open</option>
                    <option>In-Progress</option>
                    <option>Resolved</option>
                  </select>
                </div>
              </div>
            )}

            <div className="mt-6">
              <button className="px-4 py-2 bg-red-700 rounded w-full" onClick={closeIssue}>Close</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CivicIssuesPage;
