import React, { useState, useEffect, useCallback, useContext } from "react";
import { 
    fetchServicesAndEvents,
    createService,
    updateService,
    deleteService,
    createEvent,
    updateEvent,
    deleteEvent
} from "@/services/apiService";

import { AdminContext } from "../context/AdminContext";

const ServiceCard = ({ service, adminMode, onDelete, onEdit }) => (
  <div className="bg-white/10 backdrop-blur-sm p-4 rounded-lg shadow">
    <h3 className="font-bold text-lg text-white">{service.name}</h3>
    <p className="text-sm font-semibold text-blue-400">{service.type}</p>
    <p className="text-sm text-gray-300">Address: {service.address}</p>
    <p className="text-sm text-gray-300">Contact: {service.contact}</p>

    {adminMode && (
      <div className="flex gap-3 mt-4">
        <button 
          className="px-3 py-1 text-sm bg-yellow-600 rounded"
          onClick={() => onEdit(service)}
        >
          Edit
        </button>
        <button 
          className="px-3 py-1 text-sm bg-red-600 rounded"
          onClick={() => onDelete(service.id)}
        >
          Delete
        </button>
      </div>
    )}
  </div>
);

const EventCard = ({ event, adminMode, onDelete, onEdit }) => (
  <div className="bg-white/10 backdrop-blur-sm p-4 rounded-lg shadow">
    <h3 className="font-bold text-lg text-white">{event.title}</h3>
    <p className="text-sm text-gray-300">{event.description}</p>

    <div className="text-xs text-gray-400 mt-3">
      <p><strong>Date:</strong> {new Date(event.date).toLocaleDateString()}</p>
      <p><strong>Location:</strong> {event.location}</p>
      <p><strong>Organizer:</strong> {event.organizer}</p>
    </div>

    {adminMode && (
      <div className="flex gap-3 mt-4">
        <button 
          className="px-3 py-1 text-sm bg-yellow-600 rounded"
          onClick={() => onEdit(event)}
        >
          Edit
        </button>
        <button 
          className="px-3 py-1 text-sm bg-red-600 rounded"
          onClick={() => onDelete(event.id)}
        >
          Delete
        </button>
      </div>
    )}
  </div>
);

const ServicesPage = () => {
  const { adminMode } = useContext(AdminContext);

  const [services, setServices] = useState([]);
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  const [showServiceForm, setShowServiceForm] = useState(false);
  const [showEventForm, setShowEventForm] = useState(false);
  const [editingData, setEditingData] = useState(null);

  const loadAll = useCallback(async () => {
    setLoading(true);
    const data = await fetchServicesAndEvents();
    setServices(data.services);
    setEvents(data.events);
    setLoading(false);
  }, []);

  useEffect(() => {
    loadAll();
  }, []);

  // ----------------- SERVICE SUBMIT -----------------
  const submitService = async (e) => {
    e.preventDefault();

    // Generate ID for new service
    if (!editingData.id) editingData.id = `S-${Date.now()}`;

    if (editingData && editingData.id && services.find(s => s.id === editingData.id)) {
        await updateService(editingData.id, editingData);
    } else {
        await createService(editingData);
    }

    setShowServiceForm(false);
    setEditingData(null);
    loadAll();
  };


  // ----------------- EVENT SUBMIT -----------------
  const submitEvent = async (e) => {
    e.preventDefault();

    // Generate ID for new event
    if (!editingData.id) editingData.id = `E-${Date.now()}`;

    if (editingData && editingData.id && events.find(ev => ev.id === editingData.id)) {
        await updateEvent(editingData.id, editingData);
    } else {
        await createEvent(editingData);
    }

    setShowEventForm(false);
    setEditingData(null);
    loadAll();
  };


  return (
    <div className="container mx-auto">
      <h1 className="text-3xl font-bold text-white mb-6">
        Local Services & Events
      </h1>

      {/* Admin Buttons */}
      {adminMode && (
        <div className="flex gap-4 mb-6">
          <button 
            className="px-4 py-2 bg-blue-600 text-white rounded"
            onClick={() => {
              setEditingData({});
              setShowServiceForm(true);
            }}
          >
            Add Service
          </button>

          <button 
            className="px-4 py-2 bg-green-600 text-white rounded"
            onClick={() => {
              setEditingData({});
              setShowEventForm(true);
            }}
          >
            Add Event
          </button>
        </div>
      )}

      {loading ? (
        <p className="text-white">Loading...</p>
      ) : (
        <>
          <h2 className="text-xl font-semibold text-white mt-6 mb-3">Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((s) => (
              <ServiceCard 
                service={s}
                adminMode={adminMode}
                onDelete={async (id) => { await deleteService(id); loadAll(); }}
                onEdit={(data) => { setEditingData(data); setShowServiceForm(true); }}
              />
            ))}
          </div>

          <h2 className="text-xl font-semibold text-white mt-10 mb-3">Events</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {events.map((e) => (
              <EventCard 
                event={e}
                adminMode={adminMode}
                onDelete={async (id) => { await deleteEvent(id); loadAll(); }}
                onEdit={(data) => { setEditingData(data); setShowEventForm(true); }}
              />
            ))}
          </div>
        </>
      )}

      {/* SERVICE FORM */}
      {showServiceForm && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center">
          <form 
            className="bg-gray-800 p-6 rounded w-96"
            onSubmit={submitService}
          >
            <h3 className="text-white text-lg mb-4">
              {editingData?.id ? "Edit Service" : "Add Service"}
            </h3>

            <input 
              placeholder="Name"
              className="p-2 w-full mb-3 bg-gray-700 rounded text-white"
              value={editingData.name || ""}
              onChange={(e) => setEditingData({...editingData, name: e.target.value})}
            />

            <input 
              placeholder="Type"
              className="p-2 w-full mb-3 bg-gray-700 rounded text-white"
              value={editingData.type || ""}
              onChange={(e) => setEditingData({...editingData, type: e.target.value})}
            />

            <input 
              placeholder="Address"
              className="p-2 w-full mb-3 bg-gray-700 rounded text-white"
              value={editingData.address || ""}
              onChange={(e) => setEditingData({...editingData, address: e.target.value})}
            />

            <input 
              placeholder="Contact"
              className="p-2 w-full mb-3 bg-gray-700 rounded text-white"
              value={editingData.contact || ""}
              onChange={(e) => setEditingData({...editingData, contact: e.target.value})}
            />

            <button className="px-4 py-2 bg-blue-600 text-white rounded w-full mt-2">
              Save
            </button>

            <button 
              type="button"
              className="px-4 py-2 bg-red-600 text-white rounded w-full mt-2"
              onClick={() => setShowServiceForm(false)}
            >
              Cancel
            </button>
          </form>
        </div>
      )}

      {/* EVENT FORM */}
      {showEventForm && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center">
          <form 
            className="bg-gray-800 p-6 rounded w-96"
            onSubmit={submitEvent}
          >
            <h3 className="text-white text-lg mb-4">
              {editingData?.id ? "Edit Event" : "Add Event"}
            </h3>

            <input 
              placeholder="Title"
              className="p-2 w-full mb-3 bg-gray-700 rounded text-white"
              value={editingData.title || ""}
              onChange={(e) => setEditingData({...editingData, title: e.target.value})}
            />

            <input 
              type="date"
              className="p-2 w-full mb-3 bg-gray-700 rounded text-white"
              value={editingData.date || ""}
              onChange={(e) => setEditingData({...editingData, date: e.target.value})}
            />

            <input 
              placeholder="Location"
              className="p-2 w-full mb-3 bg-gray-700 rounded text-white"
              value={editingData.location || ""}
              onChange={(e) => setEditingData({...editingData, location: e.target.value})}
            />

            <textarea 
              placeholder="Description"
              className="p-2 w-full mb-3 bg-gray-700 rounded text-white"
              value={editingData.description || ""}
              onChange={(e) => setEditingData({...editingData, description: e.target.value})}
            />

            <button className="px-4 py-2 bg-green-600 text-white rounded w-full mt-2">
              Save
            </button>

            <button 
              type="button"
              className="px-4 py-2 bg-red-600 text-white rounded w-full mt-2"
              onClick={() => setShowEventForm(false)}
            >
              Cancel
            </button>
          </form>
        </div>
      )}
    </div>
  );
};

export default ServicesPage;
