import React, { useEffect, useState } from "react";
import { fetchEnvironmentalData, fetchWeatherForecast } from "@/services/apiService";

import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

const EnvironmentDashboard = () => {
  const [envData, setEnvData] = useState<any[]>([]);
  const [weatherData, setWeatherData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadAll = async () => {
      try {
        const env = await fetchEnvironmentalData();
        const weather = await fetchWeatherForecast();
        setEnvData(env);
        setWeatherData(weather);
      } catch (err) {
        console.error("Failed to load environment data:", err);
      } finally {
        setLoading(false);
      }
    };

    loadAll();
  }, []);

  if (loading) return <p className="text-white">Loading...</p>;

  if (!envData || envData.length === 0)
    return <p className="text-red-400">No environmental data available</p>;

  const latest = envData[envData.length - 1];

  return (
    <div className="container mx-auto text-white">
      <h1 className="text-3xl font-bold mb-6">Environment Dashboard</h1>

      {/* TOP CARDS */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white/10 p-4 rounded shadow">
          <h2 className="text-lg font-bold">Air Quality Index (AQI)</h2>
          <p className="text-3xl mt-2">{latest.airQuality.toFixed(1)}</p>
        </div>

        <div className="bg-white/10 p-4 rounded shadow">
          <h2 className="text-lg font-bold">Water Quality</h2>
          <p className="text-3xl mt-2">{latest.waterQuality.toFixed(1)}</p>
        </div>

        <div className="bg-white/10 p-4 rounded shadow">
          <h2 className="text-lg font-bold">Noise Level (dB)</h2>
          <p className="text-3xl mt-2">{latest.noiseLevel.toFixed(1)}</p>
        </div>
      </div>

      {/* WEATHER FORECAST CHART */}
      <div className="bg-white/5 p-6 rounded-lg shadow-lg mb-10">
        <h2 className="text-2xl font-semibold mb-4">7-Day Weather Forecast</h2>

        <ResponsiveContainer width="100%" height={350}>
          <LineChart data={weatherData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#555" />
            <XAxis dataKey="day" stroke="#ccc" />
            <YAxis stroke="#ccc" />
            <Tooltip />
            <Legend />

            <Line type="monotone" dataKey="temperature" stroke="#ffcc00" strokeWidth={3} />
            <Line type="monotone" dataKey="humidity" stroke="#00a8ff" strokeWidth={3} />
            <Line type="monotone" dataKey="rainfall" stroke="#00ff99" strokeWidth={3} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* ENVIRONMENT TREND CHART */}
      <div className="bg-white/5 p-6 rounded-lg shadow-lg">
        <h2 className="text-2xl font-semibold mb-4">30-Day Environmental Trend</h2>

        <ResponsiveContainer width="100%" height={350}>
          <LineChart data={envData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#666" />
            <XAxis dataKey="timestamp" stroke="#ccc" />
            <YAxis stroke="#ccc" />
            <Tooltip />
            <Legend />

            <Line type="monotone" dataKey="airQuality" stroke="#82ca9d" strokeWidth={3} />
            <Line type="monotone" dataKey="waterQuality" stroke="#8884d8" strokeWidth={3} />
            <Line type="monotone" dataKey="noiseLevel" stroke="#ff7675" strokeWidth={3} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <p className="text-gray-400 mt-4">
        Last Updated: {latest.timestamp}
      </p>
    </div>
  );
};

export default EnvironmentDashboard;
