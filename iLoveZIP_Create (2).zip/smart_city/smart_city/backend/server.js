// server.js
const express = require('express');
const db = require('./database.js');
const cors = require('cors');

const app = express();
const PORT = 3001;

app.use(cors());
app.use(express.json({ limit: '10mb' }));

/* -------------------- ENVIRONMENTAL DATA -------------------- */
app.get('/api/environmental-data', (req, res) => {
  const data = [];
  for (let i = 29; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    data.push({
      timestamp: date.toISOString().split('T')[0],
      airQuality: +(20 + Math.random() * 50).toFixed(2),
      waterQuality: +(6 + Math.random() * 2).toFixed(2),
      noiseLevel: +(50 + Math.random() * 20).toFixed(2),
    });
  }
  res.json({ message: 'success', data });
});

app.get("/api/weather-forecast", (req, res) => {
  const days = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"];
  const data = days.map((d) => ({
    day: d,
    temperature: 20 + Math.random() * 10,
    humidity: 40 + Math.random() * 40,
    rainfall: Math.random() * 10,
  }));

  res.json({ message: "success", data });
});

/* -------------------- ISSUES -------------------- */
// GET all issues
app.get('/api/issues', (req, res) => {
  const sql = 'SELECT * FROM issues ORDER BY timestamp DESC';
  db.all(sql, [], (err, rows) => {
    if (err) return res.status(400).json({ error: err.message });
    res.json({ message: 'success', data: rows });
  });
});

// POST new issue (citizen)
app.post('/api/issues', (req, res) => {
  const { category, description, location, photo } = req.body;
  if (!category || !description || !location) {
    return res.status(400).json({ error: 'category, description and location required' });
  }
  const newIssue = {
    id: `CI-${Date.now()}`,
    title: `${category} Report`,
    description,
    category,
    location,
    status: 'Open',
    timestamp: new Date().toISOString(),
    photo: photo || null,
  };
  const sql = 'INSERT INTO issues (id, category, title, description, location, status, timestamp, photo) VALUES (?,?,?,?,?,?,?,?)';
  const params = [newIssue.id, newIssue.category, newIssue.title, newIssue.description, newIssue.location, newIssue.status, newIssue.timestamp, newIssue.photo];
  db.run(sql, params, function (err) {
    if (err) return res.status(400).json({ error: err.message });
    res.json({ message: 'success', data: newIssue });
  });
});

// Admin-only: update issue status only
app.put('/api/issues/:id/status', (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  if (!status) return res.status(400).json({ error: 'status required' });
  const sql = 'UPDATE issues SET status = ? WHERE id = ?';
  db.run(sql, [status, id], function (err) {
    if (err) return res.status(400).json({ error: err.message });
    res.json({ message: 'updated', data: { id, status } });
  });
});

// Issue comments
app.get('/api/issues/:id/comments', (req, res) => {
  const { id } = req.params;
  const sql = 'SELECT * FROM issue_comments WHERE issue_id = ? ORDER BY timestamp ASC';
  db.all(sql, [id], (err, rows) => {
    if (err) return res.status(400).json({ error: err.message });
    res.json({ message: 'success', data: rows });
  });
});

app.post('/api/issues/:id/comments', (req, res) => {
  const { id } = req.params;
  const { author, comment } = req.body;
  if (!author || !comment) return res.status(400).json({ error: 'author and comment required' });
  const newComment = {
    id: `IC-${Date.now()}`,
    issue_id: id,
    author,
    comment,
    timestamp: new Date().toISOString(),
  };
  const sql = 'INSERT INTO issue_comments (id, issue_id, author, comment, timestamp) VALUES (?,?,?,?,?)';
  db.run(sql, [newComment.id, newComment.issue_id, newComment.author, newComment.comment, newComment.timestamp], function (err) {
    if (err) return res.status(400).json({ error: err.message });
    res.json({ message: 'success', data: newComment });
  });
});

/* -------------------- ALERTS -------------------- */
app.get('/api/alerts', (req, res) => {
  const sql = 'SELECT * FROM alerts ORDER BY timestamp DESC';
  db.all(sql, [], (err, rows) => {
    if (err) return res.status(400).json({ error: err.message });
    res.json({ message: 'success', data: rows });
  });
});

app.post('/api/alerts', (req, res) => {
  const { title, description, category, priority } = req.body;
  if (!title || !description) return res.status(400).json({ error: 'title and description required' });
  const newAlert = {
    id: `AL-${Date.now()}`,
    title,
    description,
    category: category || 'General',
    priority: priority || 'Low',
    timestamp: new Date().toISOString(),
  };
  const sql = 'INSERT INTO alerts (id, title, description, category, priority, timestamp) VALUES (?,?,?,?,?,?)';
  db.run(sql, [newAlert.id, newAlert.title, newAlert.description, newAlert.category, newAlert.priority, newAlert.timestamp], (err) => {
    if (err) return res.status(400).json({ error: err.message });
    res.json({ message: 'success', data: newAlert });
  });
});

app.put('/api/alerts/:id', (req, res) => {
  const { id } = req.params;
  const { title, description, category, priority } = req.body;
  const sql = 'UPDATE alerts SET title = ?, description = ?, category = ?, priority = ? WHERE id = ?';
  db.run(sql, [title, description, category, priority, id], function (err) {
    if (err) return res.status(400).json({ error: err.message });
    res.json({ message: 'updated', id });
  });
});

app.delete('/api/alerts/:id', (req, res) => {
  const { id } = req.params;
  db.run('DELETE FROM alerts WHERE id = ?', [id], function (err) {
    if (err) return res.status(400).json({ error: err.message });
    res.json({ message: 'deleted', id });
  });
});

/* -------------------- RESOURCES -------------------- */
app.get('/api/resources', (req, res) => {
  db.all('SELECT * FROM resources', [], (err, rows) => {
    if (err) return res.status(400).json({ error: err.message });
    res.json({ message: 'success', data: rows });
  });
});

app.post('/api/resources', (req, res) => {
  const { name, type, contact, capacity } = req.body;
  if (!name || !type) return res.status(400).json({ error: 'name and type required' });
  const newResource = { id: `R-${Date.now()}`, name, type, contact: contact || '', capacity: capacity || '', status: 'Available' };
  const sql = 'INSERT INTO resources (id, name, type, contact, capacity, status) VALUES (?,?,?,?,?,?)';
  db.run(sql, [newResource.id, newResource.name, newResource.type, newResource.contact, newResource.capacity, newResource.status], function (err) {
    if (err) return res.status(400).json({ error: err.message });
    res.json({ message: 'success', data: newResource });
  });
});

app.put('/api/resources/:id', (req, res) => {
  const { id } = req.params;
  const { name, type, contact, capacity, status } = req.body;
  const sql = 'UPDATE resources SET name=?, type=?, contact=?, capacity=?, status=? WHERE id=?';
  db.run(sql, [name, type, contact, capacity, status, id], function (err) {
    if (err) return res.status(400).json({ error: err.message });
    res.json({ message: 'updated', id });
  });
});

app.delete('/api/resources/:id', (req, res) => {
  const { id } = req.params;
  db.run('DELETE FROM resources WHERE id = ?', [id], function (err) {
    if (err) return res.status(400).json({ error: err.message });
    res.json({ message: 'deleted', id });
  });
});

/* -------------------- SERVICES & EVENTS -------------------- */
app.get('/api/services-events', (req, res) => {
  const servicesSql = 'SELECT * FROM services';
  const eventsSql = 'SELECT * FROM events ORDER BY date ASC';
  db.all(servicesSql, [], (err, services) => {
    if (err) return res.status(400).json({ error: err.message });
    db.all(eventsSql, [], (err, events) => {
      if (err) return res.status(400).json({ error: err.message });
      res.json({ message: 'success', data: { services, events } });
    });
  });
});

app.post('/api/services', (req, res) => {
  const { name, type, address, contact } = req.body;
  const newService = { id: `S-${Date.now()}`, name, type, address, contact };
  const sql = 'INSERT INTO services (id, name, type, address, contact) VALUES (?,?,?,?,?)';
  db.run(sql, [newService.id, newService.name, newService.type, newService.address, newService.contact], (err) => {
    if (err) return res.status(400).json({ error: err.message });
    res.json({ message: 'success', data: newService });
  });
});

app.put('/api/services/:id', (req, res) => {
  const { id } = req.params;
  const { name, type, address, contact } = req.body;
  const sql = 'UPDATE services SET name=?, type=?, address=?, contact=? WHERE id=?';
  db.run(sql, [name, type, address, contact, id], function (err) {
    if (err) return res.status(400).json({ error: err.message });
    res.json({ message: 'updated', id });
  });
});

app.delete('/api/services/:id', (req, res) => {
  const { id } = req.params;
  db.run('DELETE FROM services WHERE id = ?', [id], function (err) {
    if (err) return res.status(400).json({ error: err.message });
    res.json({ message: 'deleted', id });
  });
});

app.post('/api/events', (req, res) => {
  const { title, date, location, description, organizer } = req.body;
  const newEvent = { id: `E-${Date.now()}`, title, date, location, description, organizer };
  const sql = 'INSERT INTO events (id, title, date, location, description, organizer) VALUES (?,?,?,?,?,?)';
  db.run(sql, [newEvent.id, newEvent.title, newEvent.date, newEvent.location, newEvent.description, newEvent.organizer], (err) => {
    if (err) return res.status(400).json({ error: err.message });
    res.json({ message: 'success', data: newEvent });
  });
});

app.put('/api/events/:id', (req, res) => {
  const { id } = req.params;
  const { title, date, location, description, organizer } = req.body;
  const sql = 'UPDATE events SET title=?, date=?, location=?, description=?, organizer=? WHERE id=?';
  db.run(sql, [title, date, location, description, organizer, id], function (err) {
    if (err) return res.status(400).json({ error: err.message });
    res.json({ message: 'updated', id });
  });
});

app.delete('/api/events/:id', (req, res) => {
  const { id } = req.params;
  db.run('DELETE FROM events WHERE id = ?', [id], function (err) {
    if (err) return res.status(400).json({ error: err.message });
    res.json({ message: 'deleted', id });
  });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
