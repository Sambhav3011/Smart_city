// database.js
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const DB_PATH = path.resolve(__dirname, 'smartcity.db');
const db = new sqlite3.Database(DB_PATH, (err) => {
  if (err) {
    console.error('Failed to open DB:', err.message);
    throw err;
  }
  console.log('Connected to SQLite DB at', DB_PATH);
});

db.serialize(() => {
  // issues
  db.run(`
    CREATE TABLE IF NOT EXISTS issues (
      id TEXT PRIMARY KEY,
      category TEXT,
      title TEXT,
      description TEXT,
      location TEXT,
      status TEXT,
      timestamp TEXT,
      photo TEXT
    );
  `);

  // alerts
  db.run(`
    CREATE TABLE IF NOT EXISTS alerts (
      id TEXT PRIMARY KEY,
      title TEXT,
      description TEXT,
      category TEXT,
      priority TEXT,
      timestamp TEXT
    );
  `);

  // resources
  db.run(`
    CREATE TABLE IF NOT EXISTS resources (
      id TEXT PRIMARY KEY,
      name TEXT,
      type TEXT,
      contact TEXT,
      capacity TEXT,
      status TEXT
    );
  `);

  // services
  db.run(`
    CREATE TABLE IF NOT EXISTS services (
      id TEXT PRIMARY KEY,
      name TEXT,
      type TEXT,
      address TEXT,
      contact TEXT
    );
  `);

  // events
  db.run(`
    CREATE TABLE IF NOT EXISTS events (
      id TEXT PRIMARY KEY,
      title TEXT,
      description TEXT,
      date TEXT,
      location TEXT,
      organizer TEXT
    );
  `);

  // NEW: issue_comments
  db.run(`
    CREATE TABLE IF NOT EXISTS issue_comments (
      id TEXT PRIMARY KEY,
      issue_id TEXT,
      author TEXT,
      comment TEXT,
      timestamp TEXT,
      FOREIGN KEY(issue_id) REFERENCES issues(id)
    );
  `);

  // Seeds (light)
  db.get("SELECT COUNT(*) AS c FROM issues", (err, row) => {
    if (!err && row && row.c === 0) {
      const insert = `INSERT INTO issues (id, category, title, description, location, status, timestamp) VALUES (?,?,?,?,?,?,?)`;
      db.run(insert, ['CI001', 'Pothole', 'Large Pothole on Main St', 'A large and dangerous pothole near the crosswalk. Please avoid this area.', '101 Main St', 'Open', new Date().toISOString()]);
      db.run(insert, ['CI002', 'Streetlight Out', 'Streetlight out at Elm Park', 'The main streetlight at the park entrance is not working. This causes dark area at night.', 'Elm Park Entrance', 'In-Progress', new Date(Date.now() - 86400 * 1000).toISOString()]);
      console.log('Issues table seeded.');
    }
  });

  db.get("SELECT COUNT(*) AS c FROM alerts", (err, row) => {
    if (!err && row && row.c === 0) {
      const insert = `INSERT INTO alerts (id, title, description, category, priority, timestamp) VALUES (?,?,?,?,?,?)`;
      db.run(insert, ['PA001', 'Heat Wave Warning', 'Temperatures expected to exceed 95°F.', 'Weather', 'High', new Date().toISOString()]);
      db.run(insert, ['PA002', 'Road Closure on I-5', 'Major accident has closed all northbound lanes.', 'Traffic', 'Medium', new Date(Date.now() - 3600 * 1000).toISOString()]);
      console.log('Alerts table seeded.');
    }
  });

  // seed resources / services / events lightly if empty (keeps your prior logic)
  db.get("SELECT COUNT(*) AS c FROM resources", (err, row) => {
    if (!err && row && row.c === 0) {
      const insert = `INSERT INTO resources (id, name, type, contact, capacity, status) VALUES (?,?,?,?,?,?)`;
      db.run(insert, ['R001', 'John Doe', 'Volunteer', 'j.doe@email.com', 'First Aid Certified', 'Available']);
      db.run(insert, ['R002', 'Community Food Bank', 'Food Supply', '555-1234', '500 meals/day', 'Available']);
      console.log('Resources table seeded.');
    }
  });

  db.get("SELECT COUNT(*) AS c FROM services", (err, row) => {
    if (!err && row && row.c === 0) {
      const insert = `INSERT INTO services (id, name, type, address, contact) VALUES (?,?,?,?,?)`;
      db.run(insert, ['S001', 'Central General Hospital', 'Hospital', '123 Health St', '555-HOSP']);
      db.run(insert, ['S002', 'Downtown Police Dept.', 'Police Station', '100 Justice Way', '911']);
      console.log('Services table seeded.');
    }
  });

  db.get("SELECT COUNT(*) AS c FROM events", (err, row) => {
    if (!err && row && row.c === 0) {
      const insert = `INSERT INTO events (id, title, description, date, location, organizer) VALUES (?,?,?,?,?,?)`;
      db.run(insert, ['E001', 'Summer Music Festival', 'Annual music festival in Central Park.', new Date(Date.now() + 10 * 24 * 3600 * 1000).toISOString(), 'Central Park', 'City Events Committee']);
      console.log('Events table seeded.');
    }
  });
});

module.exports = db;
